<template>
  <div class="search-main">
    <section
      class="branch-search"
      role="search"
      aria-label="짐보따리 지점 찾기">
      <div class="inner">
        <!-- 지도 표시 영역 -->
        <figure class="illustration" @click="openMapModal">
          <div v-if="selectedLocation" class="map-container">
            <div ref="mapEl" class="map"></div>
            <div class="location-info">
              <h3>{{ selectedLocation.name }}</h3>
              <p>{{ selectedLocation.address }}</p>
              <p class="locker-info">{{ selectedLocation.lockers }}</p>
            </div>
            <div class="map-overlay">
              <span class="click-hint">지도를 클릭하여 자세히 보기</span>
            </div>
          </div>
          <div v-else class="placeholder">
            <div class="placeholder-icon">📍</div>
            <p>지점을 선택해보세요</p>
            <span class="click-hint">지도를 클릭하여 지점 선택</span>
          </div>
        </figure>

        <div class="content">
          <h1 class="title">짐보따리 지점 찾기</h1>
          <p class="subtitle">
            근처에 있는 짐보따리 보관소와 무인함 위치를 한눈에 확인할 수
            있습니다.
          </p>

          <form class="searchbar" @submit.prevent="selectLocationFromDropdown">
            <label class="a11y" for="branchSelect">지점 선택</label>
            <select
              id="branchSelect"
              v-model="selectedLocationId"
              class="location-select"
              @change="selectLocationFromDropdown">
              <option value="">지점을 선택해주세요</option>
              <option
                v-for="location in locations"
                :key="location.id"
                :value="location.id"
                :disabled="location.status === '점검중'">
                {{ location.name }} - {{ location.address }} ({{
                  location.distance
                }})
                <span v-if="location.status === '점검중'"> - 점검중</span>
              </option>
            </select>
            <button class="cta" type="submit" :disabled="!selectedLocationId">
              지점 확인하기
            </button>
          </form>

          <!-- 지점 선택 모달 -->
          <div v-if="showModal" class="search-modal" @click="closeModal">
            <div class="modal-content" @click.stop>
              <div class="modal-header">
                <h3>지점 선택하기</h3>
                <button class="close-btn" @click="closeModal">✕</button>
              </div>

              <div class="modal-body">
                <!-- 지점 선택 섹션 (왼쪽) -->
                <div class="location-selection-section">
                  <div class="location-list">
                    <div
                      v-for="location in locations"
                      :key="location.id"
                      class="result-item"
                      :class="{
                        disabled: location.status === '점검중',
                        selected:
                          selectedLocation &&
                          selectedLocation.id === location.id,
                      }"
                      @click="selectLocationFromModal(location.id)">
                      <div class="result-info">
                        <h4>{{ location.name }}</h4>
                        <p>{{ location.address }}</p>
                        <p class="locker-info">{{ location.lockers }}</p>
                        <div class="location-meta">
                          <span class="distance">{{ location.distance }}</span>
                          <span
                            class="status"
                            :class="
                              location.status === '운영중'
                                ? 'operating'
                                : 'maintenance'
                            ">
                            {{ location.status }}
                          </span>
                        </div>
                      </div>
                      <div class="result-icon">📍</div>
                    </div>
                  </div>
                </div>

                <!-- 지도 섹션 (오른쪽) -->
                <div class="map-section-large">
                  <div ref="modalMapEl" class="modal-map-large">
                    <!-- 기본 지도 내용 -->
                    <div
                      style="
                        width: 100%;
                        height: 100%;
                        background: #e8f4f8;
                        border-radius: 8px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        position: relative;
                        border: 2px solid #028587;
                      ">
                      <div
                        style="
                          position: absolute;
                          top: 10px;
                          left: 10px;
                          background: white;
                          padding: 8px;
                          border-radius: 4px;
                          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                          font-size: 12px;
                        ">
                        📍 지점을 선택해주세요
                      </div>
                      <div style="font-size: 48px; color: #028587">🗺️</div>
                    </div>
                  </div>
                  <div v-if="selectedLocation" class="location-card">
                    <h4>{{ selectedLocation.name }}</h4>
                    <p>{{ selectedLocation.address }}</p>
                    <p>{{ selectedLocation.lockers }}</p>
                    <div class="location-meta">
                      <span class="distance">{{
                        selectedLocation.distance
                      }}</span>
                      <span
                        class="status"
                        :class="
                          selectedLocation.status === '운영중'
                            ? 'operating'
                            : 'maintenance'
                        ">
                        {{ selectedLocation.status }}
                      </span>
                    </div>
                    <button class="directions-btn">📍 길찾기</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from "vue";

// 반응형 데이터
const selectedLocationId = ref("");
const showModal = ref(false);
const selectedLocation = ref(null);
const mapEl = ref(null);
const modalMapEl = ref(null);

// 지점 데이터 (실제로는 API에서 가져올 데이터)
const locations = [
  {
    id: 1,
    name: "칠성시장점",
    address: "대구광역시 중구 동성로2가 189-1",
    lockers: "잔여 사물함 S: 2개 XL: 2개",
    lat: 35.8714,
    lng: 128.6014,
    status: "운영중",
    distance: "0.2km",
  },
  {
    id: 2,
    name: "동성로점",
    address: "대구광역시 중구 동성로 123",
    lockers: "잔여 사물함 S: 5개 XL: 1개",
    lat: 35.87,
    lng: 128.6,
    status: "운영중",
    distance: "0.5km",
  },
  {
    id: 3,
    name: "중앙로점",
    address: "대구광역시 중구 중앙대로 456",
    lockers: "잔여 사물함 S: 3개 XL: 3개",
    lat: 35.872,
    lng: 128.602,
    status: "운영중",
    distance: "0.8km",
  },
  {
    id: 4,
    name: "서문시장점",
    address: "대구광역시 중구 대신동 115-1",
    lockers: "잔여 사물함 S: 4개 XL: 2개",
    lat: 35.8698,
    lng: 128.5856,
    status: "운영중",
    distance: "1.2km",
  },
  {
    id: 5,
    name: "반월당점",
    address: "대구광역시 중구 동성로1가 88-1",
    lockers: "잔여 사물함 S: 1개 XL: 4개",
    lat: 35.8667,
    lng: 128.5956,
    status: "운영중",
    distance: "1.5km",
  },
  {
    id: 6,
    name: "대구역점",
    address: "대구광역시 동구 동부로 149",
    lockers: "잔여 사물함 S: 6개 XL: 3개",
    lat: 35.8759,
    lng: 128.6285,
    status: "운영중",
    distance: "2.1km",
  },
  {
    id: 7,
    name: "수성못점",
    address: "대구광역시 수성구 두산동 100",
    lockers: "잔여 사물함 S: 3개 XL: 2개",
    lat: 35.8251,
    lng: 128.6304,
    status: "운영중",
    distance: "3.2km",
  },
  {
    id: 8,
    name: "동대구역점",
    address: "대구광역시 동구 동부로 149",
    lockers: "잔여 사물함 S: 2개 XL: 1개",
    lat: 35.8779,
    lng: 128.6285,
    status: "점검중",
    distance: "2.3km",
  },
];

// 지도 클릭시 모달 열기
function openMapModal() {
  showModal.value = true;
  nextTick(() => {
    if (modalMapEl.value) {
      if (window.kakao && window.kakao.maps) {
        createRealMap();
      } else {
        createDefaultMap();
      }
    }
  });
}

// 드롭다운에서 지점 선택
function selectLocationFromDropdown() {
  if (!selectedLocationId.value) {
    // 지점이 선택되지 않았으면 모달 열기
    openMapModal();
    return;
  }

  const location = locations.find(
    (loc) => loc.id === parseInt(selectedLocationId.value)
  );
  if (location) {
    selectedLocation.value = location;

    // 메인 지도 업데이트
    nextTick(() => {
      if (mapEl.value) {
        updateMainMap(location);
      }
    });
  }
}

// 모달에서 지점 선택
function selectLocationFromModal(locationId) {
  if (!locationId) return;

  const location = locations.find((loc) => loc.id === locationId);
  if (location && location.status !== "점검중") {
    selectedLocation.value = location;

    // 모달 지도 업데이트
    nextTick(() => {
      if (modalMapEl.value) {
        updateModalMap(location);
      }
    });
  }
}

// 모달 내 검색
function performSearch() {
  const query = modalSearchQuery.value.toLowerCase();

  if (query.trim() === "") {
    // 검색어가 없으면 모든 결과 표시
    searchResults.value = sampleLocations;
  } else {
    // 검색어가 있으면 필터링
    searchResults.value = sampleLocations.filter(
      (location) =>
        location.name.toLowerCase().includes(query) ||
        location.address.toLowerCase().includes(query)
    );
  }

  // 검색 결과가 있으면 첫 번째 결과를 선택
  if (searchResults.value.length > 0) {
    selectLocation(searchResults.value[0]);
  }
}

// 위치 선택
function selectLocation(location) {
  selectedLocation.value = location;
  // 모달 지도 업데이트
  nextTick(() => {
    if (modalMapEl.value) {
      updateModalMap(location);
    }
  });
}

// 모달 닫기
function closeModal() {
  showModal.value = false;
  // 선택한 위치가 있으면 메인 지도 업데이트
  if (selectedLocation.value) {
    nextTick(() => {
      if (mapEl.value) {
        updateMainMap(selectedLocation.value);
      }
    });
    // 메인 드롭다운도 업데이트
    selectedLocationId.value = selectedLocation.value.id;
  }
}

// 메인 지도 업데이트
function updateMainMap(location) {
  if (!mapEl.value) return;

  // 카카오맵이 로드되었는지 확인
  if (!window.kakao || !window.kakao.maps) {
    // 카카오맵이 없으면 기본 표시
    mapEl.value.innerHTML = `
      <div style="width: 100%; height: 100%; background: #f0f0f0; border-radius: 8px; display: flex; align-items: center; justify-content: center; position: relative;">
        <div style="position: absolute; top: 10px; left: 10px; background: white; padding: 8px; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          📍 ${location.name}
        </div>
        <div style="font-size: 24px;">🗺️</div>
      </div>
    `;
    return;
  }

  // 카카오맵 로드 완료 후 실행
  window.kakao.maps.load(() => {
    // 선택한 위치의 좌표
    const position = new window.kakao.maps.LatLng(location.lat, location.lng);

    // 지도 생성
    const mapOption = {
      center: position,
      level: 3,
    };

    const mainMap = new window.kakao.maps.Map(mapEl.value, mapOption);

    // 마커 이미지 설정
    const markerImageSrc =
      "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_red.png";
    const markerImageSize = new window.kakao.maps.Size(40, 40);
    const markerImage = new window.kakao.maps.MarkerImage(
      markerImageSrc,
      markerImageSize
    );

    // 마커 생성
    const mainMarker = new window.kakao.maps.Marker({
      position: position,
      image: markerImage,
    });
    mainMarker.setMap(mainMap);

    // 인포윈도우 표시
    const infowindow = new window.kakao.maps.InfoWindow({
      content: `<div style="padding: 10px; font-weight: bold; font-size: 14px;">${location.name}</div>`,
    });
    infowindow.open(mainMap, mainMarker);
  });
}

// 카카오맵 API 로드 및 초기화
let kakaoMap = null;
let kakaoMarker = null;
let isKakaoMapLoading = false;
let kakaoMapLoadAttempted = false;

async function loadKakaoMapAPI() {
  return new Promise((resolve, reject) => {
    // 이미 로드되었으면 바로 resolve
    if (window.kakao && window.kakao.maps) {
      resolve();
      return;
    }

    // 이미 로딩 중이면 대기
    if (isKakaoMapLoading) {
      const checkInterval = setInterval(() => {
        if (window.kakao && window.kakao.maps) {
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);
      return;
    }

    // 이미 시도했고 실패했으면 바로 reject
    if (kakaoMapLoadAttempted) {
      reject(new Error("카카오맵 API 로드 실패"));
      return;
    }

    isKakaoMapLoading = true;
    kakaoMapLoadAttempted = true;

    const script = document.createElement("script");
    script.src = "//dapi.kakao.com/v2/maps/sdk.js?autoload=false";
    script.onload = () => {
      window.kakao.maps.load(() => {
        isKakaoMapLoading = false;
        resolve();
      });
    };
    script.onerror = (error) => {
      isKakaoMapLoading = false;
      // 콘솔 경고 제거 - 정상적인 상황이므로 조용히 처리
      reject(error);
    };
    document.head.appendChild(script);
  });
}

// 실제 카카오맵 생성
function createRealMap() {
  if (!modalMapEl.value) return;

  // 카카오맵이 로드되었는지 확인
  if (!window.kakao || !window.kakao.maps) {
    createDefaultMap();
    return;
  }

  // 카카오맵 로드 완료 후 실행
  window.kakao.maps.load(() => {
    // 기본 위치 (대구 중구)
    const defaultPosition = new window.kakao.maps.LatLng(35.8714, 128.6014);

    // 지도 생성
    const mapOption = {
      center: defaultPosition,
      level: 3,
    };

    kakaoMap = new window.kakao.maps.Map(modalMapEl.value, mapOption);

    // 마커 이미지 설정
    const markerImageSrc =
      "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/marker_red.png";
    const markerImageSize = new window.kakao.maps.Size(40, 40);
    const markerImage = new window.kakao.maps.MarkerImage(
      markerImageSrc,
      markerImageSize
    );

    // 마커 생성
    kakaoMarker = new window.kakao.maps.Marker({
      position: defaultPosition,
      image: markerImage,
    });
    kakaoMarker.setMap(kakaoMap);

    console.log("카카오맵 생성 완료");
  });
}

// 기본 지도 생성
function createDefaultMap() {
  if (!modalMapEl.value) return;

  // 강제로 지도 내용 생성
  modalMapEl.value.innerHTML = `
    <div style="width: 100%; height: 100%; background: #e8f4f8; border-radius: 8px; display: flex; align-items: center; justify-content: center; position: relative; border: 2px solid #028587;">
      <div style="position: absolute; top: 10px; left: 10px; background: white; padding: 8px; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); font-size: 12px;">
        📍 지점을 선택해주세요
      </div>
      <div style="font-size: 48px; color: #028587;">🗺️</div>
    </div>
  `;
}

// 모달 지도 업데이트
function updateModalMap(location) {
  if (!modalMapEl.value) return;

  // 카카오맵이 있으면 실제 지도 업데이트
  if (kakaoMap && kakaoMarker && window.kakao && window.kakao.maps) {
    const position = new window.kakao.maps.LatLng(location.lat, location.lng);
    kakaoMap.setCenter(position);
    kakaoMarker.setPosition(position);

    // 인포윈도우 표시
    const infowindow = new window.kakao.maps.InfoWindow({
      content: `<div style="padding: 10px; font-weight: bold; font-size: 14px;">${location.name}</div>`,
    });
    infowindow.open(kakaoMap, kakaoMarker);
  } else {
    // 기본 지도 업데이트
    modalMapEl.value.innerHTML = `
      <div style="width: 100%; height: 100%; background: #e8f4f8; border-radius: 8px; display: flex; align-items: center; justify-content: center; position: relative; border: 2px solid #028587;">
        <div style="position: absolute; top: 10px; left: 10px; background: white; padding: 8px; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); font-size: 12px;">
          📍 ${location.name}
        </div>
        <div style="font-size: 48px; color: #028587;">🗺️</div>
      </div>
    `;
  }
}

onMounted(() => {
  // 초기화
});
</script>

<style scoped>
.search-main .branch-search {
  --mint: #028587;
  --mint-weak: #f4fbfb;
  --ink: #111111;
  --muted: #647074;
  --ring: rgba(2, 133, 135, 0.26);
  --radius: 12px;

  background: #fff;
  padding: clamp(60px, 7vw, 100px) 0;
}

.search-main .inner {
  width: 1320px;
  max-width: 100%;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: clamp(24px, 3vw, 40px);
  padding: 0 20px;
}

/* 일러스트 자리 */
.search-main .illustration {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 250px;
  height: 180px;
  background: var(--mint-weak);
  border-radius: 16px;
  box-shadow: inset 0 0 0 1px #e7efef;
  overflow: hidden;
  cursor: pointer;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  position: relative;
}

.search-main .illustration:hover {
  transform: translateY(-2px);
  box-shadow: inset 0 0 0 1px #e7efef, 0 4px 12px rgba(0, 0, 0, 0.1);
}

.map-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.2s ease;
  pointer-events: none;
}

.search-main .illustration:hover .map-overlay {
  opacity: 1;
}

.click-hint {
  background: rgba(255, 255, 255, 0.9);
  padding: 8px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  color: var(--mint);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

/* 지도 컨테이너 */
.map-container {
  width: 100%;
  height: 50vw;
  position: relative;
}

.map {
  width: 100%;
  height: 100%;
  border-radius: 16px;
}

.location-info {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(255, 255, 255, 0.95);
  padding: 8px;
  border-radius: 0 0 16px 16px;
}

.location-info h3 {
  font-size: 12px;
  font-weight: 700;
  margin: 0 0 2px 0;
  color: var(--ink);
}

.location-info p {
  font-size: 10px;
  margin: 0;
  color: var(--muted);
}

.locker-info {
  font-weight: 600;
  color: var(--mint) !important;
}

/* 플레이스홀더 */
.placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--muted);
}

.placeholder-icon {
  font-size: 32px;
  margin-bottom: 8px;
}

.placeholder p {
  font-size: 14px;
  margin: 0;
}

/* 텍스트 영역 */
.search-main .content {
  flex: 1;
  max-width: 600px;
}

.search-main .title {
  font-weight: 800;
  font-size: clamp(24px, 3.2vw, 32px);
  letter-spacing: -0.02em;
  color: var(--ink);
  margin-bottom: 8px;
}

.search-main .subtitle {
  font-size: clamp(14px, 1.3vw, 15px);
  color: var(--muted);
  margin-bottom: 20px;
}

/* 검색 바 */
.search-main .searchbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  max-width: 560px;
  background: #fff;
  padding: 10px;
  border-radius: calc(var(--radius) + 4px);
  border: 1px solid #f0f3f3;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.06);
  gap: 10px;
}

.search-main .searchbar input,
.search-main .searchbar select {
  flex: 1;
  height: 46px;
  border: 1px solid #e7efef;
  border-radius: var(--radius);
  padding: 0 14px;
  font-size: 15px;
  outline: none;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

.location-select {
  background: white;
  cursor: pointer;
}

.location-select:focus {
  border-color: var(--mint);
  box-shadow: 0 0 0 4px var(--ring);
}

.search-main .searchbar input::placeholder {
  color: #9aa6a9;
}

.search-main .searchbar input:focus {
  border-color: var(--mint);
  box-shadow: 0 0 0 4px var(--ring);
}

.search-main .cta {
  flex-shrink: 0;
  height: 46px;
  padding: 0 18px;
  border: none;
  border-radius: var(--radius);
  background: var(--mint);
  color: #fff;
  font-weight: 700;
  font-size: 14px;
  cursor: pointer;
  transition: transform 0.06s ease, opacity 0.15s ease;
}
.search-main .cta:hover {
  opacity: 0.95;
}
.search-main .cta:active {
  transform: translateY(1px) scale(0.99);
}

/* 모달 스타일 */
.search-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  width: 80vw;
  max-width: 1200px;
  height: 80vh;
  background: white;
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid #eee;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 700;
}

.close-btn {
  background: none;
  border: none;
  font-size: 20px;
  cursor: pointer;
  padding: 4px;
}

.modal-body {
  flex: 1;
  display: flex;
  overflow: hidden;
}

/* 지점 선택 섹션 (왼쪽) */
.location-selection-section {
  width: 35%;
  border-right: 1px solid #eee;
  display: flex;
  flex-direction: column;
  padding: 16px;
}

.location-list {
  flex: 1;
  overflow-y: auto;
}

.result-item.selected {
  background-color: var(--mint-weak);
  border-left: 4px solid var(--mint);
}

/* 지도 섹션 (오른쪽) */
.map-section-large {
  width: 65%;
  position: relative;
}

.modal-map-large {
  width: 100%;
  height: 100%;
  min-height: 500px;
  border-radius: 8px;
  border: 1px solid #ddd;
  position: relative;
  overflow: hidden;
}

.search-section {
  width: 40%;
  border-right: 1px solid #eee;
  display: flex;
  flex-direction: column;
}

.search-input {
  padding: 16px;
  border-bottom: 1px solid #eee;
  display: flex;
  gap: 8px;
}

.search-input input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
}

.result-item.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.result-item.disabled:hover {
  background-color: transparent;
}

.location-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 4px;
}

.distance {
  font-size: 11px;
  color: var(--mint);
  font-weight: 600;
}

.status {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 10px;
  font-weight: 600;
}

.status.operating {
  background: #e8f5e8;
  color: #2d5a2d;
}

.status.maintenance {
  background: #ffe8e8;
  color: #8b0000;
}

.search-input button {
  padding: 8px 12px;
  background: var(--mint);
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

.search-results {
  flex: 1;
  overflow-y: auto;
}

.result-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
  transition: background-color 0.2s;
}

.result-item:hover {
  background-color: #f8f9fa;
}

.result-info h4 {
  margin: 0 0 4px 0;
  font-size: 14px;
  font-weight: 600;
}

.result-info p {
  margin: 0;
  font-size: 12px;
  color: var(--muted);
}

.result-icon {
  font-size: 16px;
}

.no-results {
  padding: 20px;
  text-align: center;
  color: var(--muted);
}

.no-results p {
  margin: 0;
  font-size: 14px;
}

.map-section {
  flex: 1;
  position: relative;
}

.modal-map {
  width: 100%;
  height: 100%;
  min-height: 300px;
  /* background: #f8f9fa; */
  border-radius: 8px;
  border: 1px solid #ddd;
  position: relative;
  overflow: hidden;
}

.location-card {
  position: absolute;
  bottom: 16px;
  right: 16px;
  background: white;
  padding: 12px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  max-width: 200px;
}

.location-card h4 {
  margin: 0 0 4px 0;
  font-size: 14px;
  font-weight: 600;
}

.location-card p {
  margin: 0 0 4px 0;
  font-size: 12px;
  color: var(--muted);
}

.directions-btn {
  background: var(--mint);
  color: white;
  border: none;
  padding: 6px 12px;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  margin-top: 8px;
}

/* 접근성용 라벨 숨김 */
.search-main .a11y {
  position: absolute !important;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  border: 0;
  clip: rect(0 0 0 0);
  overflow: hidden;
}

/* ✅ 반응형 수정 버전 */
@media (max-width: 1024px) {
  .modal-content {
    width: 98vw;
    height: 85vh;
  }

  .location-selection-section {
    width: 40%;
  }

  .map-section-large {
    width: 60%;
  }
}

@media (max-width: 768px) {
  .search-main .inner {
    flex-direction: column;
    text-align: center;
  }

  .search-main .illustration {
    width: 200px;
    height: 150px;
  }

  .search-main .content {
    max-width: 100%;
  }

  /* 💡 인풋 크기 확대 */
  .search-main .searchbar {
    flex-direction: column;
    max-width: 90%; /* 화면의 90%로 확장 */
    margin: 0 auto;
    padding: 12px;
  }

  .search-main .searchbar input,
  .search-main .searchbar select {
    width: 100%;
    min-width: 260px;
    font-size: 15px;
  }

  .search-main .cta {
    width: 100%;
    height: 46px;
    margin-top: 8px;
  }

  /* 모달 모바일 스타일 */
  .modal-content {
    width: 95vw;
    height: 90vh;
  }

  .modal-body {
    flex-direction: column;
  }

  .location-selection-section {
    width: 100%;
    height: 45%;
    border-right: none;
    border-bottom: 1px solid #eee;
    padding: 12px;
  }

  .map-section-large {
    width: 100%;
    height: 55%;
  }

  .modal-map-large {
    min-height: 300px;
  }

  .location-card {
    position: relative;
    bottom: auto;
    right: auto;
    margin: 12px;
    max-width: none;
  }

  .result-item {
    padding: 10px 12px;
  }

  .result-info h4 {
    font-size: 13px;
  }

  .result-info p {
    font-size: 11px;
  }
}

@media (max-width: 480px) {
  .search-main .illustration {
    width: 180px;
    height: 130px;
  }

  .modal-content {
    width: 90vw;
    height: 50vh;
  }

  .location-selection-section {
    height: 40%;
    padding: 8px;
  }

  .map-section-large {
    height: 60%;
  }

  .modal-map-large {
    min-height: 250px;
  }

  .result-item {
    padding: 8px 10px;
  }

  .result-info h4 {
    font-size: 12px;
  }

  .result-info p {
    font-size: 10px;
  }

  .location-meta {
    flex-direction: column;
    align-items: flex-start;
    gap: 2px;
  }
}
</style>
