<template>
  <div class="promo-banner">
    <img src="/images/promotion/promobanner.png" alt="promotion banner" />
  </div>
  <div class="promo-inner">
    <div class="promo-benefit">
      <div class="promo-title">
        <h1>짐보따리</h1>
        <h2>신규 회원 전용 혜택</h2>
        <p>신규회원 가입 시 누릴 수 있는 다양한 혜택을 확인해보세요!</p>
      </div>
      <div class="benefit-list">
        <div class="benefit1">
          <div class="fit-title">
            <h1>Benefit</h1>
            <p>
              <svg class="emoji" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm12,152a8,8,0,0,1-16,0V98.9l-11.6,7.8a8,8,0,0,1-8.8-13.4l24-16a8.3,8.3,0,0,1,8.2-.4A8,8,0,0,1,140,84Z"
                  fill="currentColor" />
              </svg>
            </p>
          </div>

          <div class="benefit-text">
            <span class="fit-text1">신규 멤버십 쿠폰</span> <br />
            <span class="fit-text2">5,000원 할인쿠폰 지급</span>
            <span class="fit-text2">* 유효기간 : 발급일로부터 10일</span>
          </div>

          <div class="benefit1-img">
            <img src="/public/images/promotion/be1.png" alt="benefit img 1" />
          </div>
        </div>

        <!-- benefit 2 -->
        <div class="benefit2">
          <div class="fit-title">
            <h1>Benefit</h1>
            <p>
              <svg class="emoji" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm24,144a8,8,0,0,1,0,16H104a7.3,7.3,0,0,1-2.5-.4A8,8,0,0,1,96,176a7.5,7.5,0,0,1,1.7-4.9l43.7-58.3A16,16,0,0,0,128,88a15.9,15.9,0,0,0-14.7,9.8,8,8,0,0,1-14.8-6.3,32,32,0,1,1,56,30.4l-.2.3L120,168Z"
                  fill="currentColor" />
              </svg>
            </p>
          </div>

          <div class="benefit-text">
            <span class="fit-text1">생일 쿠폰 혜택</span> <br />
            <span class="fit-text2">전액 할인쿠폰 지급</span>
            <span class="fit-text2">* 유효기간 : 발급일로부터 7일</span>
          </div>

          <div class="benefit2-img">
            <img src="/public/images/promotion/be2.png" alt="benefit img 2" />
          </div>
        </div>

        <!-- benefit 3 -->
        <div class="benefit3">
          <div class="fit-title">
            <h1>Benefit</h1>
            <p>
              <svg class="emoji" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm21.5,153.5a36.2,36.2,0,0,1-51,0,8.1,8.1,0,0,1,11.4-11.4A19.9,19.9,0,1,0,124,132a8.1,8.1,0,0,1-7.1-4.3,8,8,0,0,1,.5-8.3L136.6,92H104a8,8,0,0,1,0-16h48a8.1,8.1,0,0,1,7.1,4.3,8,8,0,0,1-.5,8.3l-21.1,30a37.9,37.9,0,0,1,12,7.9,36.2,36.2,0,0,1,0,51Z"
                  fill="currentColor" />
              </svg>
            </p>
          </div>

          <div class="benefit-text">
            <span class="fit-text1">친구 초대 혜택</span> <br />
            <span class="fit-text2">초대하면 3천원, 구매하면 5천원 지급</span>
          </div>

          <div class="benefit3-img">
            <img src="/public/images/promotion/be3.png" alt="benefit img 3" />
          </div>
        </div>

        <!-- benefit4 -->
        <div class="benefit4">
          <div class="fit-title">
            <h1>Benefit</h1>
            <p>
              <svg class="emoji" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm28,152a8,8,0,0,1-16,0V152H100a8,8,0,0,1-6.5-3.4,7.9,7.9,0,0,1-1-7.3l24-68a8,8,0,0,1,15,5.4L111.3,136H140V112a8,8,0,0,1,16,0Z"
                  fill="currentColor" />
              </svg>
            </p>
          </div>

          <div class="benefit-text">
            <span class="fit-text1">리뷰 작성 시 적립금</span> <br />
            <span class="fit-text2">텍스트 리뷰 : 500원</span>
            <span class="fit-text2">사진 리뷰 : 1,000원</span>
          </div>

          <div class="benefit4-img">
            <img src="/public/images/promotion/be4.png" alt="benefit img 4" />
          </div>
        </div>
      </div>
    </div>

    <div class="detail-benefit">
      <div class="detail-title">
        <h1>Benefit</h1>
        <svg class="emoji" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M128,24A104,104,0,1,0,232,128,104.2,104.2,0,0,0,128,24Zm12,152a8,8,0,0,1-16,0V98.9l-11.6,7.8a8,8,0,0,1-8.8-13.4l24-16a8.3,8.3,0,0,1,8.2-.4A8,8,0,0,1,140,84Z"
            fill="currentColor" />
        </svg>
      </div>
      <div class="detail-txt">
        <span class="detail-txt1">신규 회원 혜택</span>
        <span class="detail-txt2">신규 가입 최대 10,000원 혜택</span>
        <span class="detail-txt3">회원가입 시 적립금 & 웰켐 쿠폰 자동 발급!</span>
      </div>

      <div class="detail-img">
        <img src="/images/promotion/coupon.png" alt="new join coupon" />
        <p>쿠폰 사용 기한 : 발급일로부터 10일 이내</p>
      </div>
    </div>
  </div>
</template>

<script setup></script>

<style lang="scss" scoped>
@import "/src/assets/style/variables";
.promo-inner {
  width: 100%;
}
.promo-benefit {
  text-align: center;
}
.promo-title h1 {
  margin-top: 100px;
  color: #000000;
  font-size: 40px;
  font-weight: 500;
}

.promo-title h2 {
  color: #028587;
  font-size: 40px;
  font-weight: 600;
}

.promo-title p {
  color: #000000;
  font-size: 25px;
  font-weight: normal;
  margin-bottom: 30px;
}

.benefit-list {
  display: grid;
  grid-template-columns: repeat(2, 300px);
  gap: 13px;
  justify-content: center;
  align-items: start;
  margin: 30px auto;
  max-width: 700px;
}

.benefit1,
.benefit2,
.benefit3,
.benefit4 {
  width: 300px;
  height: 320px;
  border: 1px solid #e0e0e0;
  display: grid;
  grid-template-rows: auto auto 1fr;
  justify-items: center;
  align-items: start;
  text-align: center;
  padding: 20px 16px;
  gap: 8px;
  text-align: center;
  box-shadow: 2px 2px 4px 3px rgba(0, 0, 0, 0.25);
}

.fit-title {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 8px;
}

.fit-title > h1 {
  // margin: 8%;
  font-size: $title-sm;
  color: #028587;
}

.emoji {
  color: #028587;
  width: 28px;
  height: 28px;
  display: block;
}

.benefit-text {
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  line-height: 0.7;
}

.benefit-text > .fit-text1 {
  font-size: $text-md;
  font-weight: 600;
  margin-bottom: 2px;
  margin-top: 6px;
}

.benefit-text > .fit-text2 {
  font-size: 8px;
  color: #a0a0a0;
  display: block;
  line-height: 1.5;
}

.benefit1-img,
.benefit2-img,
.benefit3-img,
.benefit4-img {
  width: 130px;
  height: 95px;
  display: flex;
  justify-content: center;
}

.benefit1-img img,
.benefit2-img img,
.benefit3-img img,
.benefit4-img img {
  max-width: 100%;
  max-height: 100%;
  display: block;
}

.detail-benefit {
  width: 100%;
  max-width: 710px;
  margin: 80px auto 120px;
  padding: 40px 24px;
  border: 1px solid #e0e0e0;
  background: #fff;
  text-align: center;
}

.detail-title {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  margin-bottom: 16px;
}

.detail-title > h1 {
  font-size: $quote;
  font-weight: 400;
  color: #028587;
}

.detail-title .emoji {
  color: #028587;
  text-align: center;
  width: 28px;
  height: 28px;
}

.detail-txt {
  text-align: center;
  display: flex;
  flex-direction: column;
  margin-bottom: 30px;
}
.detail-txt span:first-child {
  color: #000000;
  font-size: $title-lg;
  font-weight: 700;
  line-height: 1.3;
  margin-bottom: 25px;
}

.detail-txt > .detail-txt2 {
  font-size: $quote;
  color: #000000;
  font-weight: 600;
}

.detail-txt span:last-child {
  font-size: $quote;
  color: #000000;
  font-weight: 400;
}

.detail-img {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
}

.detail-img img {
  max-width: 300px;
  width: 100%;
  height: auto;
  object-fit: contain;
}

.detail-img p {
  font-size: $label-sm;
  color: #555353;
  font-weight: 500;
}
</style>
