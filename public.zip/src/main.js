
import "./assets/style/_main.scss"
// import "/assets/style/main.scss";

import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
const app = createApp(App);
app.use(router);
app.mount("#app");
