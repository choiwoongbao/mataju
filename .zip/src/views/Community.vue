<script setup>

</script>

<template>
  <div >
community1
  </div>
</template>

<style scoped>

</style>