<script setup>

</script>

<template>
  <div>
    <div class="inner">

    </div>
  </div>
</template>

<style scoped>

</style>