<template>
  <h1>Reservation</h1>
  <ReserveForm />
</template>

<script setup>
import ReserveForm from "@/components/reserv/ReserveForm.vue";
</script>

<style lang="scss" scoped></style>
