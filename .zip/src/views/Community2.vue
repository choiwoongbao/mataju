<script setup>

</script>

<template>
  <div >
community2
  </div>
</template>

<style scoped>

</style>