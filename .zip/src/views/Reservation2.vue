<template>
  <section class="reserve-page">
    <div class="inner">
      <Stepper :current-step="2" />

      <div class="wrap_reserv">

        <!-- 위쪽 2개 카드 (Grid 정렬) -->    
        <div class="reserve-container">
          <!-- 사물함 예약 카드 -->
          <div class="form_card line">
            <div class="card_header"><h3> 정보</h3></div>
            <div class="card_content">
              <table>
                <tbody>
                  <tr><td>성함</td><td>사물함 대여</td></tr>
                  <tr><td>휴대폰</td><td>사물함 대여</td></tr>
                  <tr><td>사물함사이즈</td><td>사물함 대여</td></tr>
                  <tr><td>대여장소</td><td>사물함 대여</td></tr>
                  <tr><td>예약날짜</td><td>사물함 대여</td></tr>
                  <tr><td>픽업장소</td><td>사물함 대여</td></tr>
                  <tr><td>배송지정일1</td><td>입력 필요</td></tr>
                  <tr><td>주소</td><td>입력 필요</td></tr>
                  <tr><td>상세주소</td><td>입력 필요</td></tr>
                  <tr><td>배송일2</td><td>입력 필요</td></tr>




                  <tr class="total"><td>총 결제금액</td><td><strong>29,000원</strong></td></tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- 선택 상품 요약 카드 -->
          <div class="summary_card line">
            <h2 class="card_title">선택 상품 요약</h2>
            <ul>
              <li v-for="tab in selectedTabs" :key="tab">
                {{ tab }} — {{ formatKrw(prices[tab]) }}
              </li>
    </ul>
    
    <div class="divider"></div>
    
    <div class="benefits">
      <h4>마일리지 / 쿠폰 사용</h4>
      <div class="benefit-row">
        <label class="inline">
          <input type="checkbox" v-model="useCoupon" />
          Welcome 쿠폰 - 3,000원
        </label>
        <span class="muted" v-if="useCoupon">- {{ formatKrw(3000) }}</span>
      </div>
      
      <div class="benefit-row">
        <label class="inline">
          <input type="checkbox" v-model="usePoints" />
          포인트 - 2,500P
        </label>
        <span class="muted" v-if="usePoints">- {{ formatKrw(2500) }}</span>
      </div>
    </div>
    
    <div class="total-row">
      <span>총 결제금액</span>
      <strong>{{ formatKrw(finalTotal) }}</strong>
    </div>
  </div>
</div>
<!-- 결제 카드 (아래에) -->
<div class="paysection">
  
  <div class="payment_card">
    <div class="card_header"><h3>결제방법 선택</h3></div>
    <div class="card_content">
      <div class="pay-grid" role="radiogroup">
        <button
        v-for="method in paymentMethods"
        :key="method.id"
        type="button"
        class="pay-card"
        :class="{ selected: selectedPayment === method.id }"
        @click="selectedPayment = method.id"
        >
        <span class="icon">{{ method.icon }}</span>
        <span class="label">{{ method.label }}</span>
      </button>
    </div>
  </div>
</div>
<button class="submit_btn" @click="saveAndPay">결제하기</button>
      </div>
    </div>
      
      
    </div>
  </section>
</template>


<script setup>
import { ref, computed } from "vue";
import Stepper from "@/components/reserv/Stepper.vue";

const selectedTabs = ref(["사물함 예약"]);
const useCoupon = ref(true);
const usePoints = ref(true);
const selectedPayment = ref("card");

const prices = {
  "사물함 예약": 29000,
  "짐 가져오기": 15000,
  "집으로 배송하기": 20000,
};

const totalPrice = computed(() =>
  selectedTabs.value.reduce((sum, tab) => sum + prices[tab], 0)
);

const discountAmount = computed(() => {
  let discount = 0;
  if (useCoupon.value) discount += 3000;
  if (usePoints.value) discount += 2500;
  return Math.min(discount, totalPrice.value);
});

const finalTotal = computed(() =>
  Math.max(totalPrice.value - discountAmount.value, 0)
);

const paymentMethods = [
  { id: "card", label: "신용카드", icon: "💳" },
  { id: "kakao", label: "카카오페이", icon: "💬 pay" },
  { id: "naver", label: "네이버페이", icon: "N pay" },
  { id: "bank", label: "무통장입금", icon: "🏦" },
];

const formatKrw = (v) =>
  new Intl.NumberFormat("ko-KR", { style: "currency", currency: "KRW" }).format(v);

const paymentLabel = computed(() => {
  const m = paymentMethods.find((p) => p.id === selectedPayment.value);
  return m ? m.label : "-";
});

const saveAndPay = () =>
  alert(`✅ 결제가 완료되었습니다!\n결제수단: ${paymentLabel.value}\n결제금액: ${formatKrw(finalTotal.value)}`);
</script>

<style lang="scss" scoped>
/* =========================================================
   💳 Reservation2 — 전면 배경 확장 적용
========================================================= */

/* ========== 1️⃣ 전면 레이아웃 ========== */
.reserve-page {
  background: #f5f7f7; /* ✅ 전면 배경 */
  min-height: 100vh;
  width: 100vw;
  padding: 80px 0;
  position: relative;
  left: 50%;
  right: 50%;
  margin-left: -50vw;
  margin-right: -50vw; /* ✅ 중앙 offset 제거 */
}

.inner {
  width: 90%;
  max-width: 1400px;
  margin: 0 auto;
}

/* ✅ 상단 레이아웃 구조 (flex → grid) */
.reserve-container {
  display: grid;
  grid-template-columns: 1fr 1fr; /* 왼쪽: 폼, 오른쪽: 요약 */
  gap: 40px;
  align-items: start;
  justify-content: center;
  margin-bottom: 60px;
  width: 90%;
  max-width: 1400px;
  margin-inline: auto;
}

/* =========================================================
   2️⃣ 카드 공통 스타일
========================================================= */
.form_card,
.summary_card,
.payment_card {
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  padding: 30px 40px;
  border: 1px solid transparent;
  position: relative;
  transition: all 0.3s ease;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 8px;
    background: #53b4a1;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }
}

/* Summary 카드 */
.summary_card {
  width: 400px;

  .card_title {
    font-size: 18px;
    font-weight: 600;
    color: #222;
    margin-bottom: 20px;
  }

  ul {
    font-size: 14px;
    color: #444;
    margin-bottom: 24px;
  }
}

/* 결제 카드 */
.payment_card {
  width: 80%;
  margin: 0 auto;

  .pay-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-bottom: 20px;
  }

  .pay-card {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 16px 0;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: #fff;
    cursor: pointer;
    transition: 0.3s;

    &:hover {
      border-color: #53b4a1;
    }

    &.selected {
      border-color: #53b4a1;
      background: #e9f8f8;
      color: #53b4a1;
      font-weight: 600;
    }

    .icon {
      font-size: 18px;
    }
  }
}
.paysection{
  width: 100%;
  display: flex;
  flex-direction: column;

}

/* 버튼 */
.submit_btn {
  width: 70%;
  padding: 14px 0;
  font-weight: 600;
  font-size: 15px;
  color: #fff;
  background: #53b4a1;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: 0.3s ease;
  display: block;
  margin: 20px auto 0;

  &:hover {
    background: #449b8a;
  }
}

/* =========================================================
   3️⃣ 내부 정렬 추가 개선 (보강용)
========================================================= */

/* ✅ 카드 내부 공통 정렬 */
.form_card,
.summary_card {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  gap: 20px;
}

/* ✅ form_card 내부 입력폼 */
.form_card .card_content {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

/* ✅ label-input 정렬 */
.form_card .form_group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

/* ✅ 주소 입력행 정렬 */
.form_card .addr-input {
  display: grid;
  grid-template-columns: 1fr auto;
  align-items: center;
  gap: 8px;
}

/* ✅ summary_card 내부 table */
.summary_card table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
  color: #444;
  margin-bottom: 16px;

  tr {
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    padding: 8px 0;
  }

  td {
    padding: 4px 0;
  }

  td:first-child {
    color: #666;
  }

  &.total {
    td:last-child {
      font-weight: 700;
      color: #53b4a1;
    }
  }
}

/* ✅ summary_card 내부 간격 */
.summary_card {
  display: grid;
  gap: 20px;

  .card_title {
    margin-bottom: 10px;
  }

  .total-row {
    display: flex;
    justify-content: space-between;
    font-weight: 600;
    font-size: 15px;
    border-top: 1px solid #e7e7e7;
    padding-top: 10px;

    strong {
      color: #53b4a1;
    }
  }
}

/* ✅ 결제 선택 그리드 */
.pay-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 12px;
}

.pay-card {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 14px 0;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: #fff;
  transition: 0.3s;

  &:hover {
    border-color: #53b4a1;
  }

  &.selected {
    background: #e9f8f8;
    border-color: #53b4a1;
    color: #53b4a1;
    font-weight: 600;
  }
}
/* =========================================================
   ✨ Line Type Variation (둥근형 → 라인형 전환)
   - .form_card.line or .summary_card.line 으로 적용 가능
========================================================= */

/* ✅ 공통 라인형 베이스 */
.form_card.line,
.summary_card.line {
  background: #fff;
  border: 1.5px solid #e1e1e1; /* 부드러운 라인 */
  box-shadow: none; /* 그림자 제거 */
  border-radius: 10px;
  padding: 28px 36px;
  position: relative;
  transition: all 0.25s ease;

  /* 🔹 컬러바 복구 + 얇게 변경 */
  &::before {
    content: "";
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 8px; 
    background: #53b4a1;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
  }


}


/* ✅ 카드 헤더 라인 스타일 */
.form_card.line .card_header,
.summary_card.line .card_header {
  border-bottom: 1px solid #e7e7e7;
  padding-bottom: 12px;
  margin-bottom: 20px;

  h3 {
    font-size: 17px;
    color: #222;
    font-weight: 600;
  }
}

/* ✅ 내부 간격 통일 */
.form_card.line .form_group {
  margin-bottom: 18px;
}

.form_card.line .label {
  color: #777;
  font-size: 13px;
}

/* ✅ summary_card 라인형 (정보 표) */
.summary_card.line table {
  border-top: 1px solid #eee;
  border-bottom: 1px solid #eee;
  padding: 10px 0;

  tr {
    border: none;
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    padding: 8px 0;
  }

  td {
    font-size: 14px;
    color: #444;
  }

  .total td:last-child {
    color: #53b4a1;
    font-weight: 600;
  }
}

/* ✅ 전환 애니메이션 */
.form_card.line,
.summary_card.line {
  transition: all 0.25s ease-in-out;
}
/* ✅ 카드 안 표(table) 정렬 간격 조정 */
.form_card.line table,
.summary_card.line table {
  border-collapse: collapse;
  width: 100%;
  font-size: 14px;
  color: #444;

  tr {
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
    padding: 4px 0; /* 🔹 기존 8px → 4px 로 줄임 */
  }

  td {
    padding: 2px 0; /* 🔹 기존 4px → 2px 로 줄임 */
  }

  td:first-child {
    color: #666;
  }

  .total td:last-child {
    color: #53b4a1;
    font-weight: 700;
  }
}

/* ✅ 카드 안 전체 여백 줄이기 */
.form_card.line .card_content,
.summary_card.line {
  padding-top: 10px; /* 🔹 상단 간격 줄이기 */
  gap: 10px;         /* 🔹 내부 요소 간 간격 축소 */
}

/* ✅ 카드 제목과 내용 사이 간격 축소 */
.form_card.line .card_header,
.summary_card.line .card_title {
  margin-bottom: 10px;
}
/* ✅ 오른쪽 summary_card 정렬 및 간격 조정 */
.summary_card.line {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-self: start; /* 🔹 상단 정렬 맞추기 */
  height: 100%; /* 🔹 높이 맞추기 */
  padding: 28px 36px;

  .card_title {
    font-size: 17px;
    font-weight: 600;
    color: #222;
    margin-bottom: 14px;
  }

  ul {
    font-size: 14px;
    color: #444;
    margin-bottom: 16px;
    line-height: 1.6;
  }

  .benefits {
    border-top: 1px solid #e7e7e7;
    padding-top: 14px;
    margin-top: 10px;

    h4 {
      font-size: 15px;
      font-weight: 600;
      margin-bottom: 10px;
      color: #222;
    }

    .benefit-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;

      label {
        font-size: 14px;
        color: #333;
      }

      .muted {
        color: #d72638;
        font-weight: 500;
      }
    }
  }

  .total-row {
    margin-top: auto;
    border-top: 1px solid #e7e7e7;
    padding-top: 12px;
    display: flex;
    justify-content: space-between;
    font-weight: 600;
    font-size: 15px;

    strong {
      color: #53b4a1;
      font-weight: 700;
    }
  }
}

/* =========================================================
   4️⃣ 반응형
========================================================= */
@media (max-width: 1024px) {
  .reserve-container {
    grid-template-columns: 1fr;
    gap: 20px;
  }

  .form_card,
  .summary_card,
  .payment_card {
    width: 90%;
  }
}

</style>

